"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

type Message = {
  id: string;
  subject?: string;
  body: string;
  fromName?: string;
  fromEmail?: string;
  status: string;
  aiSummary?: string;
};

export default function InboxPanel() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [unread, setUnread] = useState(0);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Message | null>(null);

  async function load() {
    const res = await fetch(`/api/inbox?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    setMessages(data.messages ?? []);
    setUnread(data.unread ?? 0);
  }

  useEffect(() => {
    load();
    const timer = setInterval(load, 15000);
    return () => clearInterval(timer);
  }, [query]);

  async function markRead(id: string) {
    await fetch("/api/inbox", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status: "read" }),
    });
    load();
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
      <div className="glass p-5">
        <div className="flex items-center justify-between">
          <h2 className="display text-xl font-bold">Inbox</h2>
          <span className="surface px-3 py-1 text-xs">{unread} unread</span>
        </div>

        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search messages…"
          className="surface mt-4 w-full px-4 py-3 text-sm"
        />

        <div className="mt-4 max-h-[640px] space-y-2 overflow-y-auto">
          <AnimatePresence>
            {messages.map((m) => (
              <motion.button
                key={m.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                onClick={() => {
                  setSelected(m);
                  if (m.status === "unread") markRead(m.id);
                }}
                className={`w-full rounded-xl p-4 text-left ${
                  selected?.id === m.id ? "bg-[var(--accent-soft)]" : "surface"
                }`}
              >
                <div className="flex justify-between text-xs text-[var(--muted)]">
                  <span>{m.fromEmail}</span>
                  {m.status === "unread" && <span className="h-2 w-2 rounded-full bg-[var(--accent)]" />}
                </div>
                <p className="mt-1 font-semibold">{m.subject}</p>
                <p className="mt-1 line-clamp-2 text-sm text-[var(--muted)]">{m.body}</p>
              </motion.button>
            ))}
          </AnimatePresence>
        </div>
      </div>

      <div className="glass p-6">
        {selected ? (
          <>
            <h3 className="display text-2xl font-bold">{selected.subject}</h3>
            <p className="mt-2 text-sm text-[var(--muted)]">
              {selected.fromName} · {selected.fromEmail}
            </p>

            {selected.aiSummary && (
              <div className="surface mt-5 p-4">
                <p className="text-xs uppercase tracking-widest text-[var(--accent)]">Nexora AI</p>
                <p className="mt-2 text-sm">{selected.aiSummary}</p>
              </div>
            )}

            <div className="surface mt-5 whitespace-pre-wrap p-5 text-sm">{selected.body}</div>
          </>
        ) : (
          <div className="flex h-full items-center justify-center text-[var(--muted)]">
            Select a message.
          </div>
        )}
      </div>
    </div>
  );
}
