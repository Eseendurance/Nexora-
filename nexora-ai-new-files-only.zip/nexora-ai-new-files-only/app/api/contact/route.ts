import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { runGemini } from "@/lib/gemini";
import { contactEmail, sendMail } from "@/lib/mailer";

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  company: z.string().optional(),
  phone: z.string().optional(),
  subject: z.string().min(2),
  message: z.string().min(10),
  source: z.string().default("website"),
});

export async function POST(request: Request) {
  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid form" }, { status: 400 });

  const data = parsed.data;
  let aiSummary = "";
  let aiNextAction = "";
  let priority = "normal";

  try {
    const analysis = await runGemini({
      task: "inbox",
      prompt: `Analyze this contact submission. Return JSON:
      {"aiSummary":string,"aiNextAction":string,"priority":"low"|"normal"|"high"|"urgent"}`,
      context: JSON.stringify(data),
    });
    aiSummary = analysis.aiSummary ?? "";
    aiNextAction = analysis.aiNextAction ?? "";
    priority = analysis.priority ?? "normal";
  } catch {}

  const submission = await db.contactSubmission.create({
    data: { ...data, priority, aiSummary, aiNextAction },
  });

  await db.inboxMessage.create({
    data: {
      contactId: submission.id,
      channel: "contact-form",
      subject: data.subject,
      body: data.message,
      fromName: data.name,
      fromEmail: data.email,
      aiSummary,
      aiCategory: "contact",
    },
  });

  if (process.env.CONTACT_NOTIFY_EMAIL) {
    try {
      await sendMail({
        to: process.env.CONTACT_NOTIFY_EMAIL,
        subject: `New contact submission: ${data.subject}`,
        html: contactEmail(data),
      });
    } catch {}
  }

  return NextResponse.json({ ok: true, id: submission.id });
}
